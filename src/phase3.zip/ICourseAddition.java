import java.sql.SQLException;

public interface ICourseAddition {
    void adding() throws SQLException;
}
