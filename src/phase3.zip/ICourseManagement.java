import java.sql.SQLException;

public interface ICourseManagement {
    void managecourse() throws SQLException;
}
