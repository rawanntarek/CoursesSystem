import java.sql.SQLException;

public interface Isearchingmethod {
    void search();
}